/*
 * Burp Suite 验证码识别插件 - 火白学安全增强版
 * 文件名: ocr_huobai_enhanced.java
 * 作者: 火白学安全
 * 功能: 自动识别并替换请求中的验证码占位符，完整支持参数提取和复杂数据包
 */

package burp;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.List;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ocr_huobai_enhanced implements IBurpExtender, ITab, IHttpListener, IContextMenuFactory {

    private IBurpExtenderCallbacks callbacks;
    private IExtensionHelpers helpers;
    private JPanel mainPanel;
    private JTextArea logArea;

    // 配置字段
    private JTextField ocrServerField;
    private JTextField[] captchaUrlFields = new JTextField[3];
    private JCheckBox[] captchaEnabled = new JCheckBox[3];
    private JComboBox<String>[] modeSelectors = new JComboBox[3];
    private JCheckBox debugCheckbox;
    private JTextField cookieField;

    // 参数提取相关字段
    private JTextField paramExtractField;
    private JButton saveParamsButton;
    private JCheckBox captureEnabledCheckbox;
    private JRadioButton simpleRequestRadio;
    private JRadioButton complexRequestRadio;
    private JTextArea complexRequestArea;
    private JButton testCaptureButton;

    // 用于存储请求数据包（三个接口）
    private String[] capturedRequests = new String[3];
    private String[] capturedUrls = new String[3];
    private boolean[] isComplexRequest = new boolean[3];

    // 日志相关
    private static final String LOG_PREFIX = "[OCR Enhanced] ";
    private ExecutorService executor = Executors.newFixedThreadPool(5);

    // 识别模式
    private static final String[] MODES = {
            "0 - 纯数字",
            "1 - 英文数字混合",
            "2 - 复杂验证码",
            "3 - 数学计算",
            "8 - 直接提取"
    };

    // 存储提取的参数
    private Map<String, String> extractedParams = new HashMap<>();

    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) {
        this.callbacks = callbacks;
        this.helpers = callbacks.getHelpers();

        callbacks.setExtensionName("OCR Huobai Enhanced - 完整验证码识别插件");

        // 创建UI
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                createUI();
                callbacks.addSuiteTab(ocr_huobai_enhanced.this);
            }
        });

        // 注册HTTP监听器
        callbacks.registerHttpListener(ocr_huobai_enhanced.this);

        // 注册上下文菜单
        callbacks.registerContextMenuFactory(ocr_huobai_enhanced.this);

        // 输出启动信息
        log("🔥 插件已加载 - 火白学安全增强版");
        log("📡 监听模块: 重放、爆破、抓包");
        log("🎯 验证码占位符: %huobai%1%, %huobai%2%, %huobai%3%");
        log("🔑 参数占位符: %huobai%参数名% (如: %huobai%id%, %huobai%phpsessid%)");
        log("💡 右键菜单: 发送到接口1/2/3，支持复杂数据包捕获");
    }

    private void createUI() {
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 创建顶部面板
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        JLabel titleLabel = new JLabel("验证码识别插件 v1.0 - 火白学安全", JLabel.CENTER);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        titleLabel.setForeground(new Color(0, 102, 204));

        JLabel subtitleLabel = new JLabel("完整支持复杂数据包请求和参数提取", JLabel.CENTER);
        subtitleLabel.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        subtitleLabel.setForeground(new Color(102, 102, 102));

        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);

        topPanel.add(titlePanel, BorderLayout.CENTER);

        // 创建选项卡面板
        JTabbedPane tabbedPane = new JTabbedPane();

        // 选项卡1: 基本配置
        JPanel basicTab = createBasicConfigPanel();
        tabbedPane.addTab("📋 基本配置", basicTab);

        // 选项卡2: 参数提取配置
        JPanel paramTab = createParamConfigPanel();
        tabbedPane.addTab("🔑 参数提取", paramTab);

        // 选项卡3: 请求捕获
        JPanel captureTab = createCapturePanel();
        tabbedPane.addTab("🎯 请求捕获", captureTab);

        // 选项卡4: 调试信息
        JPanel debugTab = createDebugPanel();
        tabbedPane.addTab("🐛 调试信息", debugTab);

        // 日志区域
        JPanel logPanel = new JPanel(new BorderLayout());
        logPanel.setBorder(BorderFactory.createTitledBorder("📝 运行日志"));
        logArea = new JTextArea(20, 60);
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(logArea);

        // 日志按钮面板
        JPanel logButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton clearLogButton = new JButton("清空日志");
        clearLogButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logArea.setText("");
            }
        });

        JButton exportLogButton = new JButton("导出日志");
        exportLogButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportLog();
            }
        });

        logButtonPanel.add(clearLogButton);
        logButtonPanel.add(exportLogButton);

        logPanel.add(scrollPane, BorderLayout.CENTER);
        logPanel.add(logButtonPanel, BorderLayout.SOUTH);

        // 添加到主面板
        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(logPanel, BorderLayout.SOUTH);

        // 初始化数组
        for (int i = 0; i < 3; i++) {
            capturedRequests[i] = "";
            capturedUrls[i] = "";
            isComplexRequest[i] = false;
        }
    }

    private JPanel createBasicConfigPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // OCR服务器配置
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.weightx = 1.0;
        JPanel serverPanel = new JPanel(new BorderLayout());
        serverPanel.setBorder(BorderFactory.createTitledBorder("OCR服务器配置"));

        JPanel serverInputPanel = new JPanel(new BorderLayout(10, 0));
        JLabel serverLabel = new JLabel("服务器地址:");
        ocrServerField = new JTextField("127.0.0.1:8899");
        ocrServerField.setToolTipText("OCR服务地址，格式：IP:端口 或 http://IP:端口");

        serverInputPanel.add(serverLabel, BorderLayout.WEST);
        serverInputPanel.add(ocrServerField, BorderLayout.CENTER);
        serverPanel.add(serverInputPanel, BorderLayout.CENTER);
        panel.add(serverPanel, gbc);
        gbc.weightx = 0;

        // Cookie配置
        gbc.gridy = 1;
        JPanel cookiePanel = new JPanel(new BorderLayout());
        cookiePanel.setBorder(BorderFactory.createTitledBorder("Cookie配置"));

        JPanel cookieInputPanel = new JPanel(new BorderLayout());
        JLabel cookieLabel = new JLabel("Cookie:");
        cookieField = new JTextField();
        cookieField.setToolTipText("访问验证码URL时使用的Cookie，可为空");

        cookieInputPanel.add(cookieLabel, BorderLayout.WEST);
        cookieInputPanel.add(cookieField, BorderLayout.CENTER);
        cookiePanel.add(cookieInputPanel, BorderLayout.CENTER);
        panel.add(cookiePanel, gbc);

        // 三个验证码接口配置
        for (int i = 0; i < 3; i++) {
            gbc.gridy = i + 2;
            gbc.gridwidth = 1;

            // 启用复选框
            gbc.gridx = 0;
            gbc.weightx = 0.1;
            captchaEnabled[i] = new JCheckBox("接口 " + (i + 1));
            captchaEnabled[i].setSelected(true);
            captchaEnabled[i].setToolTipText("启用/禁用该接口");
            panel.add(captchaEnabled[i], gbc);

            // 验证码URL输入框
            gbc.gridx = 1;
            gbc.weightx = 0.7;
            JPanel urlPanel = new JPanel(new BorderLayout());
            urlPanel.setBorder(BorderFactory.createTitledBorder(
                    "验证码URL " + (i + 1) + " (对应 %huobai%" + (i + 1) + "%)"
            ));
            captchaUrlFields[i] = new JTextField();
            captchaUrlFields[i].setToolTipText("验证码图片的URL地址，可为完整URL或相对路径");
            urlPanel.add(captchaUrlFields[i], BorderLayout.CENTER);
            panel.add(urlPanel, gbc);

            // 模式选择器
            gbc.gridx = 2;
            gbc.weightx = 0.2;
            JPanel modePanel = new JPanel(new BorderLayout());
            modePanel.setBorder(BorderFactory.createTitledBorder("识别模式"));
            modeSelectors[i] = new JComboBox<>(MODES);
            modeSelectors[i].setSelectedIndex(1);
            modeSelectors[i].setToolTipText("选择验证码识别模式");
            modePanel.add(modeSelectors[i], BorderLayout.CENTER);
            panel.add(modePanel, gbc);

            gbc.weightx = 0;
        }

        // 调试选项和测试按钮
        gbc.gridy = 5;
        gbc.gridx = 0;
        gbc.gridwidth = 3;
        gbc.weightx = 1.0;
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        debugCheckbox = new JCheckBox("开启调试模式");
        debugCheckbox.setToolTipText("开启详细调试日志");
        actionPanel.add(debugCheckbox);

        JButton testButton = new JButton("测试所有接口");
        testButton.setToolTipText("测试所有启用的验证码接口");
        testButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                testAllInterfaces();
            }
        });
        actionPanel.add(testButton);

        JButton clearConfigButton = new JButton("清空配置");
        clearConfigButton.setToolTipText("清空所有配置");
        clearConfigButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearAllConfig();
            }
        });
        actionPanel.add(clearConfigButton);

        panel.add(actionPanel, gbc);

        // 添加弹性空间
        gbc.gridy = 6;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.VERTICAL;
        panel.add(Box.createVerticalGlue(), gbc);

        return panel;
    }

    private JPanel createParamConfigPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // 参数提取配置
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 3;
        gbc.weightx = 1.0;
        JPanel paramPanel = new JPanel(new BorderLayout());
        paramPanel.setBorder(BorderFactory.createTitledBorder("参数提取配置"));

        JPanel inputPanel = new JPanel(new BorderLayout(10, 0));
        JLabel paramLabel = new JLabel("要提取的参数名（用逗号分隔，如: id,token,phpsessid）:");
        paramExtractField = new JTextField();
        paramExtractField.setToolTipText("输入要从验证码响应中提取的参数名，多个用逗号分隔");

        saveParamsButton = new JButton("保存配置");
        saveParamsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String params = paramExtractField.getText().trim();
                if (!params.isEmpty()) {
                    log("✅ 已保存参数提取配置: " + params);
                    JOptionPane.showMessageDialog(mainPanel,
                            "参数提取配置已保存！\n" +
                                    "配置的参数: " + params + "\n" +
                                    "在请求中使用 %huobai%参数名% 格式进行替换",
                            "保存成功",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    log("⚠️ 参数提取配置已清空");
                }
            }
        });

        inputPanel.add(paramLabel, BorderLayout.NORTH);
        inputPanel.add(paramExtractField, BorderLayout.CENTER);
        inputPanel.add(saveParamsButton, BorderLayout.EAST);

        paramPanel.add(inputPanel, BorderLayout.CENTER);
        panel.add(paramPanel, gbc);

        // 提取的参数显示
        gbc.gridy = 1;
        JPanel extractedPanel = new JPanel(new BorderLayout());
        extractedPanel.setBorder(BorderFactory.createTitledBorder("已提取的参数"));

        JTextArea extractedArea = new JTextArea(8, 50);
        extractedArea.setEditable(false);
        extractedArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane extractedScroll = new JScrollPane(extractedArea);

        JButton refreshButton = new JButton("刷新");
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateExtractedParamsDisplay(extractedArea);
            }
        });

        JButton clearParamsButton = new JButton("清空");
        clearParamsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                extractedParams.clear();
                extractedArea.setText("");
                log("🗑️ 已清空所有提取的参数");
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(refreshButton);
        buttonPanel.add(clearParamsButton);

        extractedPanel.add(extractedScroll, BorderLayout.CENTER);
        extractedPanel.add(buttonPanel, BorderLayout.SOUTH);
        panel.add(extractedPanel, gbc);

        // 使用说明
        gbc.gridy = 2;
        JPanel helpPanel = new JPanel(new BorderLayout());
        helpPanel.setBorder(BorderFactory.createTitledBorder("💡 使用说明"));
        JTextArea helpArea = new JTextArea(
                "1. 在左侧输入要提取的参数名（如: id,token,phpsessid,csrf_token）\n" +
                        "2. 点击'保存配置'按钮保存设置\n" +
                        "3. 插件会自动从验证码响应中提取这些参数的值\n" +
                        "4. 在请求中使用 %huobai%参数名% 格式进行替换\n" +
                        "5. 例如: %huobai%phpsessid% 会被替换为提取的phpsessid值\n" +
                        "6. 支持多个参数同时提取和替换\n" +
                        "7. 参数名区分大小写，必须完全一致"
        );
        helpArea.setEditable(false);
        helpArea.setBackground(panel.getBackground());
        helpArea.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        helpPanel.add(helpArea, BorderLayout.CENTER);
        panel.add(helpPanel, gbc);

        // 添加弹性空间
        gbc.gridy = 3;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.VERTICAL;
        panel.add(Box.createVerticalGlue(), gbc);

        return panel;
    }

    private JPanel createCapturePanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        // 启用/禁用捕获功能
        JPanel enablePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        enablePanel.setBorder(BorderFactory.createTitledBorder("请求捕获功能"));
        captureEnabledCheckbox = new JCheckBox("启用请求捕获", false);
        captureEnabledCheckbox.setToolTipText("启用后可以从右键菜单捕获请求");
        captureEnabledCheckbox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean enabled = captureEnabledCheckbox.isSelected();
                simpleRequestRadio.setEnabled(enabled);
                complexRequestRadio.setEnabled(enabled);
                complexRequestArea.setEnabled(enabled && complexRequestRadio.isSelected());
                testCaptureButton.setEnabled(enabled);
            }
        });
        enablePanel.add(captureEnabledCheckbox);

        // 请求类型选择
        JPanel typePanel = new JPanel(new GridLayout(1, 2, 10, 0));
        typePanel.setBorder(BorderFactory.createTitledBorder("请求类型"));

        ButtonGroup requestTypeGroup = new ButtonGroup();
        simpleRequestRadio = new JRadioButton("简单URL请求", true);
        complexRequestRadio = new JRadioButton("复杂数据包请求");
        simpleRequestRadio.setEnabled(false);
        complexRequestRadio.setEnabled(false);

        // 添加事件监听器
        simpleRequestRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                complexRequestArea.setEnabled(false);
                complexRequestArea.setText("");
                log("📡 已选择简单URL请求模式");
            }
        });

        complexRequestRadio.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                complexRequestArea.setEnabled(true);
                log("🎯 已选择复杂数据包请求模式");
            }
        });

        requestTypeGroup.add(simpleRequestRadio);
        requestTypeGroup.add(complexRequestRadio);

        typePanel.add(simpleRequestRadio);
        typePanel.add(complexRequestRadio);

        // 复杂请求数据包区域
        JPanel complexPanel = new JPanel(new BorderLayout());
        complexPanel.setBorder(BorderFactory.createTitledBorder("数据包内容 (仅复杂数据包模式使用)"));
        complexRequestArea = new JTextArea(15, 60);
        complexRequestArea.setEditable(false);
        complexRequestArea.setEnabled(false);
        complexRequestArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane complexScrollPane = new JScrollPane(complexRequestArea);
        complexPanel.add(complexScrollPane, BorderLayout.CENTER);

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        testCaptureButton = new JButton("测试捕获的数据包");
        testCaptureButton.setEnabled(false);
        testCaptureButton.setToolTipText("测试当前捕获的数据包是否能正常获取验证码");
        testCaptureButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                testCapturedRequest();
            }
        });

        JButton clearButton = new JButton("清空捕获");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearCapturedData();
            }
        });

        JButton viewHistoryButton = new JButton("查看接口状态");
        viewHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showInterfaceStatus();
            }
        });

        buttonPanel.add(testCaptureButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(viewHistoryButton);

        // 状态显示
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createTitledBorder("状态信息"));
        JTextArea statusArea = new JTextArea(3, 50);
        statusArea.setEditable(false);
        statusArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        statusArea.setText("捕获功能已关闭。从右键菜单'发送到接口X'可自动启用捕获。\n" +
                "简单URL模式: 直接使用URL获取验证码\n" +
                "复杂数据包模式: 使用完整HTTP数据包获取验证码");
        statusPanel.add(new JScrollPane(statusArea), BorderLayout.CENTER);

        // 布局组装
        JPanel northPanel = new JPanel(new BorderLayout());
        northPanel.add(enablePanel, BorderLayout.NORTH);
        northPanel.add(typePanel, BorderLayout.SOUTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(complexPanel, BorderLayout.CENTER);
        centerPanel.add(buttonPanel, BorderLayout.SOUTH);

        panel.add(northPanel, BorderLayout.NORTH);
        panel.add(centerPanel, BorderLayout.CENTER);
        panel.add(statusPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createDebugPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JTextArea debugArea = new JTextArea(20, 60);
        debugArea.setEditable(false);
        debugArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        debugArea.setText(
                "🛠️ 调试信息面板\n" +
                        "================\n\n" +
                        "插件版本: 3.0 增强版\n" +
                        "作者: 火白学安全\n" +
                        "最后更新: 2024\n\n" +
                        "🔧 功能模块状态:\n" +
                        "1. 基本配置模块: ✅ 正常\n" +
                        "2. 参数提取模块: ✅ 正常\n" +
                        "3. 请求捕获模块: ✅ 正常\n" +
                        "4. 复杂数据包支持: ✅ 完整支持\n" +
                        "5. 参数替换功能: ✅ 完整支持\n\n" +
                        "📋 使用流程:\n" +
                        "1. 配置OCR服务器地址 (默认: 127.0.0.1:8899)\n" +
                        "2. 设置验证码URL和识别模式\n" +
                        "3. 配置要提取的参数名\n" +
                        "4. 在Burp请求中使用 %huobai%1% 等占位符\n" +
                        "5. 插件会自动识别验证码并替换占位符\n\n" +
                        "🎯 复杂数据包使用:\n" +
                        "1. 右键点击请求 -> 发送到接口X\n" +
                        "2. 自动启用请求捕获和复杂数据包模式\n" +
                        "3. 插件会使用完整数据包获取验证码\n" +
                        "4. 同时提取响应中的参数\n\n" +
                        "🐛 常见问题:\n" +
                        "1. 验证码识别失败: 检查OCR服务是否运行\n" +
                        "2. 参数未替换: 检查参数名是否正确配置\n" +
                        "3. 复杂数据包失败: 检查数据包格式是否正确\n" +
                        "4. 参数名区分大小写: 配置的参数名必须与提取的参数名完全一致\n"
        );

        JScrollPane scrollPane = new JScrollPane(debugArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    @Override
    public void processHttpMessage(int toolFlag, boolean messageIsRequest, IHttpRequestResponse messageInfo) {
        // 只处理请求，不处理响应
        if (!messageIsRequest) {
            return;
        }

        // 只监听指定的工具：重放(Intruder)、爆破(Repeater)、抓包(Proxy)
        if (toolFlag != IBurpExtenderCallbacks.TOOL_INTRUDER &&
                toolFlag != IBurpExtenderCallbacks.TOOL_REPEATER &&
                toolFlag != IBurpExtenderCallbacks.TOOL_PROXY) {
            return;
        }

        // 获取请求内容
        byte[] requestBytes = messageInfo.getRequest();
        String requestStr = helpers.bytesToString(requestBytes);

        // 检查是否包含需要替换的关键词
        boolean hasPlaceholder = false;

        // 检查验证码占位符
        for (int i = 1; i <= 3; i++) {
            if (requestStr.contains("%huobai%" + i + "%")) {
                hasPlaceholder = true;
                break;
            }
        }

        // 检查参数占位符
        String paramNames = paramExtractField.getText().trim();
        if (!paramNames.isEmpty()) {
            String[] params = paramNames.split(",");
            for (String param : params) {
                param = param.trim();
                if (!param.isEmpty() && requestStr.contains("%huobai%" + param + "%")) {
                    hasPlaceholder = true;
                    break;
                }
            }
        }

        if (!hasPlaceholder) {
            return;
        }

        String toolName = getToolName(toolFlag);
        log("🎯 检测到占位符，开始处理请求 - 工具: " + toolName);

        // 同步处理验证码识别和替换
        try {
            processCaptchaReplacement(messageInfo, requestStr, toolFlag);
        } catch (Exception e) {
            log("❌ 处理验证码时发生错误: " + e.getMessage());
            if (debugCheckbox.isSelected()) {
                e.printStackTrace();
            }
        }
    }

    private void processCaptchaReplacement(IHttpRequestResponse messageInfo, String requestStr, int toolFlag) {
        String modifiedRequest = requestStr;
        boolean modified = false;

        // 获取请求的详细信息
        IRequestInfo requestInfo = helpers.analyzeRequest(messageInfo);
        List<String> headers = new ArrayList<>(requestInfo.getHeaders());

        // 处理验证码占位符
        for (int i = 1; i <= 3; i++) {
            String placeholder = "%huobai%" + i + "%";

            if (requestStr.contains(placeholder)) {
                // 检查该接口是否启用
                if (!captchaEnabled[i-1].isSelected()) {
                    log("⚠️ 接口 " + i + " 未启用，跳过 " + placeholder);
                    continue;
                }

                String captchaUrl = captchaUrlFields[i-1].getText().trim();
                if (captchaUrl.isEmpty()) {
                    log("⚠️ 接口 " + i + " 的URL未设置，跳过 " + placeholder);
                    continue;
                }

                try {
                    // 获取识别模式
                    String mode = ((String) modeSelectors[i-1].getSelectedItem()).split(" - ")[0];

                    // 获取Cookie配置
                    String cookieToUse = cookieField.getText().trim();

                    // 确定请求类型和复杂数据包
                    String requestType = "1"; // 默认简单请求
                    String complexRequestData = "";

                    // 检查是否为复杂数据包请求
                    if (isComplexRequest[i-1] && !capturedRequests[i-1].isEmpty()) {
                        requestType = "2";
                        complexRequestData = capturedRequests[i-1];
                        log("🎯 接口 " + i + " 使用复杂数据包请求模式");
                        if (debugCheckbox.isSelected()) {
                            log("调试 - 数据包长度: " + complexRequestData.length());
                            log("调试 - 数据包前200字符: " + complexRequestData.substring(0, Math.min(200, complexRequestData.length())));
                        }
                    } else {
                        log("📡 接口 " + i + " 使用简单URL请求模式");
                    }

                    log("🔄 正在识别验证码 - 接口: " + i + ", URL: " + captchaUrl + ", 模式: " + mode);

                    // 调用OCR服务识别验证码
                    String[] ocrResult = recognizeCaptcha(captchaUrl, mode, cookieToUse, requestType, complexRequestData);

                    String captchaText = ocrResult[0];
                    String extractedParamsStr = ocrResult[1];

                    if (captchaText != null && !captchaText.equals("0000")) {
                        // 替换验证码占位符
                        modifiedRequest = modifiedRequest.replace(placeholder, captchaText);
                        modified = true;

                        log("✅ 接口 " + i + " 识别成功: " + captchaText);

                        // 如果有提取的参数，处理参数替换
                        if (extractedParamsStr != null && !extractedParamsStr.isEmpty()) {
                            Map<String, String> paramMap = parseExtractedParams(extractedParamsStr);

                            // 更新全局参数存储
                            extractedParams.putAll(paramMap);

                            // 获取要提取的参数名
                            String paramNames = paramExtractField.getText().trim();
                            if (!paramNames.isEmpty()) {
                                String[] params = paramNames.split(",");
                                for (String param : params) {
                                    param = param.trim();
                                    if (!param.isEmpty()) {
                                        String paramPlaceholder = "%huobai%" + param + "%";
                                        if (modifiedRequest.contains(paramPlaceholder)) {
                                            // 严格区分大小写的精确匹配
                                            String paramValue = paramMap.get(param);

                                            if (paramValue != null && !paramValue.isEmpty()) {
                                                modifiedRequest = modifiedRequest.replace(paramPlaceholder, paramValue);
                                                modified = true;
                                                log("🔑 已替换参数 " + param + ": " + paramValue);
                                            } else {
                                                log("⚠️ 参数 " + param + " 未在提取结果中找到（区分大小写）");
                                                if (debugCheckbox.isSelected()) {
                                                    log("调试 - 当前提取的参数列表: " + paramMap.keySet());
                                                    log("调试 - 您指定的参数名: " + param);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        String toolName = getToolName(toolFlag);
                        log(toolName + " - 已替换 " + placeholder + " -> " + captchaText);

                        if (debugCheckbox.isSelected()) {
                            log("调试 - 验证码URL: " + captchaUrl);
                            log("调试 - 识别模式: " + mode);
                            log("调试 - 请求类型: " + requestType);
                            log("调试 - 提取的参数: " + (extractedParamsStr != null ? extractedParamsStr : "空"));
                        }
                    } else {
                        log("❌ 接口 " + i + " 识别失败: " + captchaText);
                    }
                } catch (Exception e) {
                    log("❌ 接口 " + i + " 处理失败: " + e.getMessage());
                    if (debugCheckbox.isSelected()) {
                        e.printStackTrace();
                    }
                }
            }
        }

        if (modified) {
            // 重新构建请求
            int bodyOffset = requestInfo.getBodyOffset();
            String body = modifiedRequest.substring(bodyOffset);
            byte[] newRequestBytes = helpers.buildHttpMessage(headers, body.getBytes());

            // 更新请求
            messageInfo.setRequest(newRequestBytes);

            log("✅ 请求已成功更新并发送");

            // 调试：检查更新后的请求
            if (debugCheckbox.isSelected()) {
                String newRequestStr = helpers.bytesToString(newRequestBytes);
                log("调试 - 更新后的请求片段:");
                int startIndex = Math.max(0, newRequestStr.indexOf("%huobai%") - 50);
                int endIndex = Math.min(newRequestStr.length(), startIndex + 200);
                if (startIndex < endIndex) {
                    String snippet = newRequestStr.substring(startIndex, endIndex);
                    snippet = snippet.replaceAll("password=[^&]*", "password=***");
                    log(snippet);
                }
            }
        } else {
            log("⚠️ 请求未修改（可能是所有接口都未启用或识别失败）");
        }
    }

    private String[] recognizeCaptcha(String captchaUrl, String mode, String cookie, String requestType, String complexRequest) {
        String[] result = new String[2]; // [0]验证码文本, [1]提取的参数
        result[0] = "0000";
        result[1] = "";

        try {
            String ocrServer = ocrServerField.getText().trim();
            if (ocrServer.isEmpty()) {
                ocrServer = "127.0.0.1:8899";
            }

            // 确保地址有协议
            if (!ocrServer.startsWith("http://") && !ocrServer.startsWith("https://")) {
                ocrServer = "http://" + ocrServer;
            }

            // 确保路径正确
            if (!ocrServer.endsWith("/imgurl")) {
                if (ocrServer.endsWith("/")) {
                    ocrServer = ocrServer + "imgurl";
                } else {
                    ocrServer = ocrServer + "/imgurl";
                }
            }

            if (debugCheckbox.isSelected()) {
                log("调试 - 调用OCR服务: " + ocrServer);
                log("调试 - 验证码URL: " + captchaUrl);
                log("调试 - 识别模式: " + mode);
                log("调试 - 请求类型: " + requestType);
                if (requestType.equals("2")) {
                    log("调试 - 复杂数据包长度: " + (complexRequest != null ? complexRequest.length() : 0));
                }
            }

            // 构建POST请求参数
            String postData = buildPostData(captchaUrl, mode, cookie, requestType, complexRequest);

            if (debugCheckbox.isSelected() && requestType.equals("2")) {
                log("调试 - POST数据长度: " + postData.length());
            }

            // 发送请求到OCR服务器
            URL url = new URL(ocrServer);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("User-Agent", "BurpOCR/3.0");
            conn.setRequestProperty("Accept", "*/*");
            conn.setRequestProperty("Connection", "keep-alive");
            conn.setDoOutput(true);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] postBytes = postData.getBytes("UTF-8");
                os.write(postBytes);
                os.flush();

                if (debugCheckbox.isSelected()) {
                    log("调试 - 发送POST数据长度: " + postBytes.length);
                }
            }

            // 读取响应
            int responseCode = conn.getResponseCode();
            if (debugCheckbox.isSelected()) {
                log("调试 - 响应码: " + responseCode);
            }

            if (responseCode == 200) {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        response.append(line);
                    }

                    // 解析响应
                    String fullResponse = response.toString();

                    if (debugCheckbox.isSelected()) {
                        log("调试 - 完整响应: " + fullResponse);
                    }

                    // 按"|"分割响应
                    String[] parts = fullResponse.split("\\|", 2);

                    // 第一部分总是验证码
                    result[0] = parts[0];

                    // 第二部分是提取的参数（如果有）
                    if (parts.length >= 2) {
                        result[1] = parts[1];
                    }

                    if (debugCheckbox.isSelected()) {
                        log("调试 - 解析结果 - 验证码: " + result[0]);
                        log("调试 - 解析结果 - 参数: " + result[1]);
                    }
                }
            } else {
                log("❌ OCR服务器响应错误: " + responseCode);
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getErrorStream(), "UTF-8"))) {
                    StringBuilder errorResponse = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        errorResponse.append(line);
                    }
                    log("错误响应: " + errorResponse.toString());
                }
            }
        } catch (Exception e) {
            log("❌ 调用OCR服务失败: " + e.getMessage());
            if (debugCheckbox.isSelected()) {
                e.printStackTrace();
            }
        }

        return result;
    }

    private String buildPostData(String captchaUrl, String mode, String cookie, String requestType, String complexRequest) {
        try {
            Map<String, String> params = new HashMap<>();

            // 编码验证码URL
            String xp_url_base64 = Base64.getEncoder().encodeToString(captchaUrl.getBytes("UTF-8"));
            params.put("xp_url", xp_url_base64);

            // 请求类型：1表示简单GET请求，2表示复杂数据包请求
            params.put("xp_type", requestType);

            // Cookie
            String cookieToEncode = cookie == null ? "" : cookie;
            params.put("xp_cookie", Base64.getEncoder().encodeToString(cookieToEncode.getBytes("UTF-8")));

            // 识别模式
            params.put("xp_set_ranges", mode);

            // 复杂请求数据包
            String complexRequestToEncode = complexRequest == null ? "" : complexRequest;
            params.put("xp_complex_request", Base64.getEncoder().encodeToString(complexRequestToEncode.getBytes("UTF-8")));

            // 不使用正则
            params.put("xp_rf", "0");
            params.put("xp_re", Base64.getEncoder().encodeToString("".getBytes("UTF-8")));
            params.put("xp_is_re_run", "false");

            // 构建POST数据
            StringBuilder postData = new StringBuilder();
            for (Map.Entry<String, String> param : params.entrySet()) {
                if (postData.length() != 0) {
                    postData.append('&');
                }
                postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
                postData.append('=');
                postData.append(URLEncoder.encode(param.getValue(), "UTF-8"));
            }

            return postData.toString();
        } catch (Exception e) {
            log("❌ 构建POST数据失败: " + e.getMessage());
            return "";
        }
    }

    private Map<String, String> parseExtractedParams(String extractedParams) {
        Map<String, String> paramMap = new HashMap<>();

        if (extractedParams == null || extractedParams.isEmpty()) {
            return paramMap;
        }

        // 分割参数（格式：key1=value1;key2=value2）
        String[] pairs = extractedParams.split(";");
        for (String pair : pairs) {
            String[] keyValue = pair.split("=", 2);
            if (keyValue.length == 2) {
                String key = keyValue[0].trim();
                String value = keyValue[1].trim();
                paramMap.put(key, value);
            }
        }

        return paramMap;
    }

    private void testAllInterfaces() {
        log("🚀 开始测试所有接口...");

        for (int i = 0; i < 3; i++) {
            if (captchaEnabled[i].isSelected()) {
                String urlText = captchaUrlFields[i].getText().trim();
                final String url = urlText;
                final int interfaceIndex = i + 1;
                final int modeSelectorIndex = i;

                if (!url.isEmpty()) {
                    executor.submit(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                String mode = ((String) modeSelectors[modeSelectorIndex].getSelectedItem()).split(" - ")[0];
                                String cookieToUse = cookieField.getText().trim();

                                // 确定请求类型
                                String requestType = "1";
                                String complexRequestData = "";
                                if (isComplexRequest[interfaceIndex-1] && !capturedRequests[interfaceIndex-1].isEmpty()) {
                                    requestType = "2";
                                    complexRequestData = capturedRequests[interfaceIndex-1];
                                    log("测试接口 " + interfaceIndex + " - 使用复杂数据包模式");
                                }

                                log("测试接口 " + interfaceIndex + " - URL: " + url + " - 模式: " + mode);
                                String[] result = recognizeCaptcha(url, mode, cookieToUse, requestType, complexRequestData);
                                SwingUtilities.invokeLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (result[0] != null && !result[0].equals("0000")) {
                                            log("✅ 接口 " + interfaceIndex + " 测试成功: " + result[0]);
                                            if (result[1] != null && !result[1].isEmpty()) {
                                                log("提取的参数: " + result[1]);
                                            }
                                        } else {
                                            log("❌ 接口 " + interfaceIndex + " 测试失败");
                                        }
                                    }
                                });
                            } catch (Exception e) {
                                SwingUtilities.invokeLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        log("❌ 接口 " + interfaceIndex + " 测试异常: " + e.getMessage());
                                    }
                                });
                            }
                        }
                    });
                } else {
                    log("⚠️ 接口 " + (i + 1) + " URL为空，跳过测试");
                }
            }
        }
    }

    private void testCapturedRequest() {
        if (!captureEnabledCheckbox.isSelected()) {
            log("⚠️ 请先启用请求捕获功能");
            return;
        }

        if (!complexRequestRadio.isSelected()) {
            log("⚠️ 请选择复杂数据包请求模式");
            return;
        }

        String complexRequestData = complexRequestArea.getText().trim();
        if (complexRequestData.isEmpty()) {
            log("⚠️ 数据包内容为空，请先捕获请求");
            return;
        }

        // 获取第一个有URL的接口
        int interfaceIndex = -1;
        String testUrl = "";
        for (int i = 0; i < 3; i++) {
            String url = captchaUrlFields[i].getText().trim();
            if (!url.isEmpty()) {
                interfaceIndex = i;
                testUrl = url;
                break;
            }
        }

        if (interfaceIndex == -1) {
            log("❌ 没有配置验证码URL，请先在基本配置中设置URL");
            return;
        }

        // 将这些局部变量设为 final，以便在内部类中使用
        final String finalTestUrl = testUrl;
        final String finalMode = ((String) modeSelectors[interfaceIndex].getSelectedItem()).split(" - ")[0];
        final String finalCookieToUse = cookieField.getText().trim();
        final String finalComplexRequestData = complexRequestData;

        log("🧪 测试捕获的数据包 - 接口: " + (interfaceIndex + 1) + ", URL: " + finalTestUrl);
        log("数据包长度: " + finalComplexRequestData.length());

        executor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    String[] result = recognizeCaptcha(finalTestUrl, finalMode, finalCookieToUse, "2", finalComplexRequestData);
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            if (result[0] != null && !result[0].equals("0000")) {
                                log("✅ 复杂数据包测试成功: " + result[0]);
                                if (result[1] != null && !result[1].isEmpty()) {
                                    log("提取的参数: " + result[1]);
                                    // 更新提取的参数显示
                                    Map<String, String> paramMap = parseExtractedParams(result[1]);
                                    extractedParams.putAll(paramMap);
                                }
                            } else {
                                log("❌ 复杂数据包测试失败");
                            }
                        }
                    });
                } catch (Exception e) {
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            log("❌ 复杂数据包测试异常: " + e.getMessage());
                        }
                    });
                }
            }
        });
    }

    private void clearCapturedData() {
        for (int i = 0; i < 3; i++) {
            capturedRequests[i] = "";
            capturedUrls[i] = "";
            isComplexRequest[i] = false;
        }
        complexRequestArea.setText("");
        captureEnabledCheckbox.setSelected(false);
        simpleRequestRadio.setSelected(true);
        log("🗑️ 已清空所有捕获的数据");
    }

    private void showInterfaceStatus() {
        StringBuilder status = new StringBuilder();
        status.append("接口状态:\n");
        status.append("========\n");

        for (int i = 0; i < 3; i++) {
            status.append("接口 ").append(i + 1).append(":\n");
            status.append("  URL: ").append(captchaUrlFields[i].getText().trim().isEmpty() ? "未设置" : "已设置").append("\n");
            status.append("  启用: ").append(captchaEnabled[i].isSelected() ? "是" : "否").append("\n");
            status.append("  模式: ").append(modeSelectors[i].getSelectedItem()).append("\n");
            status.append("  捕获数据: ").append(capturedRequests[i].isEmpty() ? "无" : capturedRequests[i].length() + " 字节").append("\n");
            status.append("  请求类型: ").append(isComplexRequest[i] ? "复杂数据包" : "简单URL").append("\n");
            status.append("  -----------------\n");
        }

        JTextArea statusArea = new JTextArea(status.toString());
        statusArea.setEditable(false);
        statusArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(statusArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));

        JOptionPane.showMessageDialog(mainPanel, scrollPane, "接口状态", JOptionPane.INFORMATION_MESSAGE);
    }

    private void updateExtractedParamsDisplay(JTextArea extractedArea) {
        if (extractedParams.isEmpty()) {
            extractedArea.setText("暂无提取的参数");
            return;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("已提取的参数 (").append(extractedParams.size()).append(" 个):\n");
        sb.append("====================\n");

        for (Map.Entry<String, String> entry : extractedParams.entrySet()) {
            sb.append(entry.getKey()).append(" = ").append(entry.getValue()).append("\n");
        }

        extractedArea.setText(sb.toString());
    }

    private void clearAllConfig() {
        int result = JOptionPane.showConfirmDialog(mainPanel,
                "确定要清空所有配置吗？\n包括：\n1. 验证码URL\n2. 参数提取配置\n3. 捕获的数据\n4. Cookie设置",
                "确认清空",
                JOptionPane.YES_NO_OPTION);

        if (result == JOptionPane.YES_OPTION) {
            // 清空基本配置
            ocrServerField.setText("127.0.0.1:8899");
            cookieField.setText("");

            // 清空三个接口配置
            for (int i = 0; i < 3; i++) {
                captchaUrlFields[i].setText("");
                captchaEnabled[i].setSelected(true);
                modeSelectors[i].setSelectedIndex(1);
            }

            // 清空参数提取配置
            paramExtractField.setText("");
            extractedParams.clear();

            // 清空捕获数据
            clearCapturedData();

            log("✅ 所有配置已清空");
        }
    }

    private void exportLog() {
        try {
            String logText = logArea.getText();
            if (logText.trim().isEmpty()) {
                JOptionPane.showMessageDialog(mainPanel, "日志为空，无法导出", "导出失败", JOptionPane.WARNING_MESSAGE);
                return;
            }

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("导出日志");
            fileChooser.setSelectedFile(new java.io.File("ocr_plugin_log.txt"));

            if (fileChooser.showSaveDialog(mainPanel) == JFileChooser.APPROVE_OPTION) {
                java.io.File file = fileChooser.getSelectedFile();
                try (java.io.PrintWriter out = new java.io.PrintWriter(file, "UTF-8")) {
                    out.println("=== Burp OCR Plugin Log ===");
                    out.println("导出时间: " + new java.util.Date());
                    out.println("===========================\n");
                    out.print(logText);
                }
                log("📤 日志已导出到: " + file.getAbsolutePath());
            }
        } catch (Exception e) {
            log("❌ 导出日志失败: " + e.getMessage());
        }
    }

    private void log(String message) {
        final String logMessage = LOG_PREFIX + message + "\n";

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                logArea.append(logMessage);
                logArea.setCaretPosition(logArea.getDocument().getLength());
            }
        });

        // 同时输出到Burp控制台
        callbacks.printOutput(logMessage);
    }

    private String getToolName(int toolFlag) {
        switch (toolFlag) {
            case IBurpExtenderCallbacks.TOOL_PROXY:
                return "代理";
            case IBurpExtenderCallbacks.TOOL_REPEATER:
                return "重放";
            case IBurpExtenderCallbacks.TOOL_INTRUDER:
                return "爆破";
            default:
                return "未知";
        }
    }

    @Override
    public String getTabCaption() {
        return "OCR Enhanced";
    }

    @Override
    public Component getUiComponent() {
        return mainPanel;
    }

    @Override
    public java.util.List<JMenuItem> createMenuItems(IContextMenuInvocation invocation) {
        java.util.List<JMenuItem> menuItems = new java.util.ArrayList<>();

        IHttpRequestResponse[] messages = invocation.getSelectedMessages();
        if (messages != null && messages.length > 0) {
            // 获取选中的请求
            IHttpRequestResponse message = messages[0];
            byte[] requestBytes = message.getRequest();
            String requestStr = helpers.bytesToString(requestBytes);

            // 分析请求
            IRequestInfo requestInfo = helpers.analyzeRequest(message);
            String url = requestInfo.getUrl().toString();

            // 创建三个菜单项：发送到接口1、接口2、接口3
            for (int i = 1; i <= 3; i++) {
                final int interfaceIndex = i;
                JMenuItem sendToInterfaceItem = new JMenuItem("发送到接口" + interfaceIndex);
                sendToInterfaceItem.setToolTipText("将当前请求发送到接口" + interfaceIndex + "，并自动启用复杂数据包模式");

                sendToInterfaceItem.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // 启用捕获功能
                        captureEnabledCheckbox.setSelected(true);

                        // 自动选择复杂数据包请求
                        complexRequestRadio.setSelected(true);
                        complexRequestArea.setEnabled(true);

                        // 保存到对应的接口
                        capturedRequests[interfaceIndex - 1] = requestStr;
                        capturedUrls[interfaceIndex - 1] = url;
                        isComplexRequest[interfaceIndex - 1] = true;

                        // 更新显示
                        complexRequestArea.setText(requestStr);

                        // 同时将URL填入对应接口
                        captchaUrlFields[interfaceIndex - 1].setText(url);

                        log("🎯 已捕获请求到接口" + interfaceIndex + ": " + url);
                        log("请求长度: " + requestStr.length() + " 字节");
                        log("已自动启用复杂数据包请求模式");

                        // 询问是否立即测试
                        int testResult = JOptionPane.showConfirmDialog(mainPanel,
                                "请求已捕获到接口" + interfaceIndex + "。\n" +
                                        "URL: " + url + "\n" +
                                        "长度: " + requestStr.length() + " 字节\n\n" +
                                        "是否立即测试该数据包？",
                                "请求捕获成功",
                                JOptionPane.YES_NO_OPTION);

                        if (testResult == JOptionPane.YES_OPTION) {
                            testCapturedRequest();
                        }
                    }
                });
                menuItems.add(sendToInterfaceItem);
            }

            // 添加分隔符（使用一个不可用的菜单项模拟分隔符）
            JMenuItem separator1 = new JMenuItem("-");
            separator1.setEnabled(false);
            menuItems.add(separator1);

            // 添加到所有接口
            JMenuItem sendToAllItem = new JMenuItem("发送到所有接口");
            sendToAllItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    captureEnabledCheckbox.setSelected(true);
                    complexRequestRadio.setSelected(true);
                    complexRequestArea.setEnabled(true);

                    for (int i = 0; i < 3; i++) {
                        capturedRequests[i] = requestStr;
                        capturedUrls[i] = url;
                        isComplexRequest[i] = true;
                        captchaUrlFields[i].setText(url);
                    }

                    complexRequestArea.setText(requestStr);

                    log("🎯 已捕获请求到所有3个接口");
                    log("URL: " + url);
                    log("长度: " + requestStr.length() + " 字节");
                }
            });
            menuItems.add(sendToAllItem);
        }

        // 添加分隔符（使用一个不可用的菜单项模拟分隔符）
        JMenuItem separator2 = new JMenuItem("-");
        separator2.setEnabled(false);
        menuItems.add(separator2);

        // 手动识别验证码菜单项
        JMenuItem manualOcrItem = new JMenuItem("手动识别验证码");
        manualOcrItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 创建一个对话框
                JPanel panel = new JPanel(new GridBagLayout());
                GridBagConstraints gbc = new GridBagConstraints();
                gbc.fill = GridBagConstraints.HORIZONTAL;
                gbc.insets = new Insets(5, 5, 5, 5);

                gbc.gridx = 0;
                gbc.gridy = 0;
                panel.add(new JLabel("验证码URL:"), gbc);

                gbc.gridx = 1;
                gbc.gridwidth = 2;
                gbc.weightx = 1.0;
                JTextField urlField = new JTextField(40);
                panel.add(urlField, gbc);

                gbc.gridx = 0;
                gbc.gridy = 1;
                gbc.gridwidth = 1;
                gbc.weightx = 0;
                panel.add(new JLabel("识别模式:"), gbc);

                gbc.gridx = 1;
                JComboBox<String> modeCombo = new JComboBox<>(MODES);
                panel.add(modeCombo, gbc);

                gbc.gridx = 2;
                JCheckBox complexCheck = new JCheckBox("复杂数据包");
                panel.add(complexCheck, gbc);

                gbc.gridx = 0;
                gbc.gridy = 2;
                gbc.gridwidth = 3;
                JTextArea requestArea = new JTextArea(5, 40);
                requestArea.setBorder(BorderFactory.createTitledBorder("数据包内容（仅复杂数据包模式）"));
                requestArea.setEnabled(false);
                JScrollPane scrollPane = new JScrollPane(requestArea);
                panel.add(scrollPane, gbc);

                complexCheck.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        requestArea.setEnabled(complexCheck.isSelected());
                    }
                });

                int result = JOptionPane.showConfirmDialog(mainPanel, panel,
                        "手动识别验证码", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    String url = urlField.getText().trim();
                    if (!url.isEmpty()) {
                        String mode = ((String) modeCombo.getSelectedItem()).split(" - ")[0];
                        String cookie = cookieField.getText().trim();

                        String requestType = complexCheck.isSelected() ? "2" : "1";
                        String complexRequestData = complexCheck.isSelected() ? requestArea.getText() : "";

                        executor.submit(new Runnable() {
                            @Override
                            public void run() {
                                String[] ocrResult = recognizeCaptcha(url, mode, cookie, requestType, complexRequestData);
                                SwingUtilities.invokeLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (ocrResult[0] != null && !ocrResult[0].equals("0000")) {
                                            JOptionPane.showMessageDialog(mainPanel,
                                                    "验证码识别结果: " + ocrResult[0] +
                                                            (ocrResult[1] != null && !ocrResult[1].isEmpty() ?
                                                                    "\n提取的参数: " + ocrResult[1] : ""),
                                                    "识别成功",
                                                    JOptionPane.INFORMATION_MESSAGE);
                                            log("✅ 手动识别成功: " + ocrResult[0]);
                                        } else {
                                            JOptionPane.showMessageDialog(mainPanel,
                                                    "验证码识别失败",
                                                    "识别失败",
                                                    JOptionPane.ERROR_MESSAGE);
                                            log("❌ 手动识别失败");
                                        }
                                    }
                                });
                            }
                        });
                    }
                }
            }
        });

        menuItems.add(manualOcrItem);

        return menuItems;
    }
}